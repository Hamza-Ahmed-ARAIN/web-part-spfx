import * as React from "react";
import styles from "./ApplicationCategories.module.scss";
import { IApplicationCategoriesProps } from "./IApplicationCategoriesProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { escape } from "@microsoft/sp-lodash-subset";
import "./style.css";
import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";
let url = "";
export interface IApplicationstate {
  Products: any;
}
export default class ApplicationCategories extends React.Component<
  IApplicationCategoriesProps,
  IApplicationstate
> {
  ProductId: number = null;
  constructor(props) {
    super(props);
    // SPComponentLoader.loadCss(
    //   "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    // );

    var queryParms = new UrlQueryParameterCollection(window.location.href);
    this.ProductId = parseInt(queryParms.getValue("PeramId"));
    // var  ProductId= parseInt(queryParms.getValue("ProductLineId"));
    this.state = {
      Products: [],
    };
    console.log("this is my id" + this.ProductId);

    url = this.props.spfxcontext.pageContext.web.absoluteUrl;
  }
  componentDidMount() {
    this.getData(this.ProductId).then((Response) => {
      this.setState({ Products: Response.value });
    });
  }

  public render(): React.ReactElement<IApplicationCategoriesProps> {
    return (
      <div className="container">
        <div className="row">
          {this.state.Products.length > 0
            ? this.state.Products.map((item) => (
                <div className="col-lg-3 col-md-4 col-sm-6 col-xs-12 mar">
                  <div className="card">
                    <a
                      href={
                        "https://stateindus7600242.sharepoint.com/sites/StateChemSML/SitePages/Product.aspx?PeramId=" +
                        item.ID
                      }
                    >
                      <img
                        className="card-img-top"
                        src={item.AttachmentFiles[0].ServerRelativeUrl}
                        alt="images"
                      />

                      <div className="card-body">
                        <h5 className="card-text">{item.Title}</h5>
                      </div>
                    </a>
                  </div>
                </div>
              ))
            : ""}
        </div>
      </div>
    );
  }
  private logMessageToConsole(message: string) {
    var queryParms = new UrlQueryParameterCollection(window.location.href);
    if (queryParms.getValue("PeramId")) {
      console.log(message);
    }
  }
  public getData(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Products')/items?$select=*,AttachmentFiles,Application/ID&$expand=AttachmentFiles,Application/ID&$filter=Application/ID eq ` +
      id +
      ``;
    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
}

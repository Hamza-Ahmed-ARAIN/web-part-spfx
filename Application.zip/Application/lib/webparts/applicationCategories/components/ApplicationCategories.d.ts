import * as React from "react";
import { IApplicationCategoriesProps } from "./IApplicationCategoriesProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
export interface IApplicationstate {
    Products: any;
}
export default class ApplicationCategories extends React.Component<IApplicationCategoriesProps, IApplicationstate> {
    ProductId: number;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IApplicationCategoriesProps>;
    private logMessageToConsole;
    getData(id: any): Promise<any>;
}
//# sourceMappingURL=ApplicationCategories.d.ts.map
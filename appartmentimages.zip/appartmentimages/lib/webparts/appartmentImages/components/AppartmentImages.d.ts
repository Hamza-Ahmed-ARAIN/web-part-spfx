import * as React from "react";
import { IAppartmentImagesProps } from "./IAppartmentImagesProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
export interface IAppartmentstate {
    Products: any;
}
export default class AppartmentImages extends React.Component<IAppartmentImagesProps, IAppartmentstate> {
    ProductId: number;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IAppartmentImagesProps>;
    getData(id: any): Promise<any>;
}
//# sourceMappingURL=AppartmentImages.d.ts.map
declare interface IAppartmentImagesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AppartmentImagesWebPartStrings' {
  const strings: IAppartmentImagesWebPartStrings;
  export = strings;
}

/* tslint:disable */
require("./AppartmentImages.module.css");
const styles = {
  appartmentImages: 'appartmentImages_dcd0314c',
  container: 'container_dcd0314c',
  row: 'row_dcd0314c',
  column: 'column_dcd0314c',
  'ms-Grid': 'ms-Grid_dcd0314c',
  title: 'title_dcd0314c',
  subTitle: 'subTitle_dcd0314c',
  description: 'description_dcd0314c',
  button: 'button_dcd0314c',
  label: 'label_dcd0314c'
};

export default styles;
/* tslint:enable */
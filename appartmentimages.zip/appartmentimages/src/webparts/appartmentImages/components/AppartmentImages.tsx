import * as React from "react";
import styles from "./AppartmentImages.module.scss";
import { IAppartmentImagesProps } from "./IAppartmentImagesProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { escape } from "@microsoft/sp-lodash-subset";
import "./style.css";
import {
  SPHttpClient,
  SPHttpClientResponse,
  IHttpClientOptions,
  SPHttpClientConfiguration,
  IDigestCache,
  DigestCache,
} from "@microsoft/sp-http";
import { UrlQueryParameterCollection } from "@microsoft/sp-core-library";
const logo: any = require("./assets/ban.png");
let url = "";
export interface IAppartmentstate {
  Products: any;
}
export default class AppartmentImages extends React.Component<
  IAppartmentImagesProps,
  IAppartmentstate
> {
  ProductId: number = null;

  constructor(props) {
    super(props);
    // SPComponentLoader.loadCss(
    //   "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    // );

    var queryParms = new UrlQueryParameterCollection(window.location.href);
    this.ProductId = parseInt(queryParms.getValue("PeramId"));
    // var  ProductId= parseInt(queryParms.getValue("ProductLineId"));
    this.state = {
      Products: [],
    };
    console.log("this is my id" + this.ProductId);

    url = this.props.spfxcontext.pageContext.web.absoluteUrl;
  }
  componentDidMount() {
    this.getData(this.ProductId).then((Response) => {
      this.setState({ Products: Response.value });
    });
  }
  public render(): React.ReactElement<IAppartmentImagesProps> {
    return (
      <div>
        {this.state.Products.length > 0
          ? this.state.Products.map((item) => (
              <img
                className="img-rounded  img-fluid appart"
                src={item.AttachmentFiles[0].ServerRelativeUrl}
                alt="images"
              />
            ))
          : ""}
      </div>
    );
  }
  public getData(id): Promise<any> {
    // let ListURL:string=`${url}/_api/web/lists/getbytitle('Products')/items?$select=*,${colName},ID,AttachmentFiles&$expand=AttachmentFiles&$orderby=${this.props.listColOrderBy} asc`;
    let ListURL: string =
      `${url}/_api/web/lists/getbytitle('Market')/items?$select=*,AttachmentFiles&$expand=AttachmentFiles&$filter=ID eq ` +
      id +
      ``;
    try {
      return this.props.spfxcontext.spHttpClient
        .get(ListURL, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json();
        });
    } catch (error) {
      console.dir(error);
      return Promise.reject(error);
    }
  }
}

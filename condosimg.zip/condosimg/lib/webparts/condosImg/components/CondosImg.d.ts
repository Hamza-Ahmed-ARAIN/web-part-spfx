import * as React from "react";
import { ICondosImgProps } from "./ICondosImgProps";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
export interface ICondosstate {
    Description: string;
    Title: string;
}
export default class CondosImg extends React.Component<ICondosImgProps, ICondosstate> {
    ProductId: number;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<ICondosImgProps>;
    getData(id: any): Promise<any>;
    htmlDecode(value: any): string;
}
//# sourceMappingURL=CondosImg.d.ts.map
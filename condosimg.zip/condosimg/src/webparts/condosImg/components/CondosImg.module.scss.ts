/* tslint:disable */
require("./CondosImg.module.css");
const styles = {
  condosImg: 'condosImg_f476e833',
  container: 'container_f476e833',
  row: 'row_f476e833',
  column: 'column_f476e833',
  'ms-Grid': 'ms-Grid_f476e833',
  title: 'title_f476e833',
  subTitle: 'subTitle_f476e833',
  description: 'description_f476e833',
  button: 'button_f476e833',
  label: 'label_f476e833'
};

export default styles;
/* tslint:enable */
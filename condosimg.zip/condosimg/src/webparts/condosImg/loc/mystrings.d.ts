declare interface ICondosImgWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CondosImgWebPartStrings' {
  const strings: ICondosImgWebPartStrings;
  export = strings;
}
